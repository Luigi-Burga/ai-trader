"""AI Trader application package."""
